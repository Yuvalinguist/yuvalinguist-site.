# Yuval Linguistics — starter website

This is a first design prototype, with placeholder biography, research, CV and contact details. Do not publish as final until the text has been personalized.

## Publish on GitHub Pages
1. Create a public GitHub repository, e.g. `yuvalinguist-site`.
2. Upload `index.html` and `CNAME` to the root of the repository.
3. Under Settings → Pages, select **Deploy from a branch**, branch **main**, folder **/(root)**.
4. In Pages settings, set custom domain to `yuvalinguist.com`.
5. At the domain registrar, set the apex-domain A records according to GitHub's *current* documentation: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site
6. Wait for DNS and certificate issuance, then enable **Enforce HTTPS** when available.

Avoid sharing login credentials or DNS account access.
